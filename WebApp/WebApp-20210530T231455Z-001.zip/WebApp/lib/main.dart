import 'dart:collection';
import 'package:flutter/scheduler.dart';
import 'package:flutter/material.dart';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';

import 'package:flutter/material.dart';
import "signin.dart";
import 'package:flutter_login/theme.dart';

void main() {
  runApp(new MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      title: 'Admin - Chloe : University of Oregon',
      theme: new ThemeData(
        primarySwatch: Colors.blueGrey
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  var names = ['Minnie Mouse', 'Nadela', 'Sushi'];
  var times = [
    "5/29/2021 7:31:00 AM",
    "5/29/2021 6:53:00 AM",
    "5/29/2021 4:06:09 AM"
  ];
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text('Admin - Chloe : University of Oregon'),
      ),
      body: new GridView.count(
        crossAxisCount: 4,
        children: new List<Widget>.generate(8, (index) {
          return InkWell(
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (BuildContext context) {
                    return Scaffold(
                      appBar: AppBar(
                        title: const Text('University of Oregon'),
                      ),
                      body: Hero(
                        tag: 'asspass',
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: ListView.separated(
                            separatorBuilder:
                                (BuildContext context, int index) =>
                                    const Divider(),
                            itemCount: 3,
                            itemBuilder: (BuildContext context, int index) {
                              return ListTile(
                                title: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text("${names[index]}"),
                                    Text("${times[index]}")
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                    );
                  },
                ),
              );
            },
            // Main route
            child: Hero(
                tag: 'flippers',
                child: Container(
                    height: 20,
                    width: 20,
                    color: Colors.lightBlue,
                    child: Center(child: Text("$index", style: TextStyle(color: Colors.white, fontSize: 60))))),
          );
        }),
      ),
    );
  }
}

/*
class BasicHeroAnimation extends StatelessWidget {
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Basic Hero Animation'),
      ),
      body: Center(
        child: 
      ),
    );
  }
}
*/
