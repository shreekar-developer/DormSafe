import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_login/theme.dart';
import 'package:flutter_login/flutter_login.dart';
import 'main.dart';
import 'package:flutter_login/theme.dart';

import 'ver.dart';
import 'package:flutter/material.dart';
import 'package:flutter_login/flutter_login.dart';
// import 'dashboard_screen.dart';
/*
FirebaseAuth auth = FirebaseAuth.instance;

// FirebaseAuth.instance
//   .authStateChanges()
//   .listen((User user) {
//     if (user == null) {
//       print('User is currently signed out!');
//     } else {
//       print('User is signed in!');
//     }
//   });

class LoginScreen extends StatelessWidget {
  Duration get loginTime => Duration(milliseconds: 0);

  Future<String> _authUser(LoginData data) {
    return Future.delayed(loginTime).then((_) async {
      try {
        UserCredential userCredential = await FirebaseAuth.instance
            .signInWithEmailAndPassword(
                email: data.name, password: data.password);
      } on FirebaseAuthException catch (e) {
        if (e.code == 'user-not-found') {
          return 'No user found for that email.';
        } else if (e.code == 'wrong-password') {
          return 'Wrong password provided for that user.';
        }
      }
      FirebaseAuth.instance.authStateChanges().listen((User? user) {
        //took out the question near the User
        if (user == null) {
          print('User is currently signed out!');
        } else {
          print('User is signed in!');
        }
      });
      return "null";
    });
  }

  Future<String> _recoverPassword(String name) {
    print('Name: $name');
    return Future.delayed(loginTime).then((_) {
      if (true) {
        return 'Username not exists';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return FlutterLogin(
      title: 'Admin - DormSafe',
      logo: 'assets/hacka.png',
      onLogin: _authUser,
      onSignup: _authUser,
      onSubmitAnimationCompleted: () {
        Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (context) => MyHomePage(
                  title: 'DormSafe',
                )));
      },
      onRecoverPassword: _recoverPassword,
    );
  }
}
*/
