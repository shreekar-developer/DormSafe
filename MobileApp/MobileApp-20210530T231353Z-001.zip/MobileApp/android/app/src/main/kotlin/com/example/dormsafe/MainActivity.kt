package com.example.dormsafe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
